import firebase from "firebase/app";
import "firebase/auth";
import firebaseConfig from './firebase.config';

export const intializeLoginFramework = () => {
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
     }else {
        firebase.app(); // if already initialized, use that one
     }
}


export const handleGoogleSignIn = () => {
    const googleProvider = new firebase.auth.GoogleAuthProvider();
    return firebase.auth().signInWithPopup(googleProvider)
      .then(result => {
        const { displayName, photoURL, email } = result.user;
        const signedInUser = {
          isSignedIn: true,
          name: displayName,
          photo: photoURL,
            email: email,
          success: true
        }
        console.log(result);
        return signedInUser;
      })

      .catch(err => {
        console.log(err);
        console.log(err.message);
      })
  }


export const handleFbSignIn = () => {
    const fbProvider = new firebase.auth.FacebookAuthProvider();
    return firebase.auth().signInWithPopup(fbProvider)
  .then((result) => {
    var credential = result.credential;
      var user = result.user;
      user.success= true;
      return user;
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
  });
}
  
export const handleSignOut = () => {
    return firebase.auth().signOut()
      .then(result => {
        const signedOutUser = {
          isSignedIn: false,
          name: '',
          email: '',
          password: '',
          photo: '',
          error: '',
          success: false,
        }
        return signedOutUser;   
      })
    .catch(err => {console.log(err)})
  }


export const createUserWithEmailAndPassword = ( name, email,password) => {
   return  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then(res => {
        const newUserInfo = res.user;
      newUserInfo.error = '';
      newUserInfo.success = true;
        updateUserName(name);
        return newUserInfo;
    })
    .catch(error => {
      const newUserInfo = {};
      newUserInfo.error = error.message;
      newUserInfo.success = false;
        return newUserInfo;
  });
}
  
export const signInWithEmailAndPassword = (email,password) => {
    return firebase.auth().signInWithEmailAndPassword(email,password)
  .then(res => {
    const newUserInfo = res.user;
    newUserInfo.error = '';
    newUserInfo.success = true;
    alert('Log In successfully completed 😍');
   return newUserInfo;
      

  })
        .catch((error) => {
          const newUserInfo = {};
          newUserInfo.error = error.message;
          newUserInfo.success = false;
          console.log(newUserInfo);
            return newUserInfo;
  });
}

export const updateUserName = name => {
    const  user = firebase.auth().currentUser;
user.updateProfile({
  displayName: name,
}).then(function() {
  // Update successful.
  console.log("username Updated successfully");
}).catch(function(error) {
  // An error happened.
  console.log(error);
});
  }